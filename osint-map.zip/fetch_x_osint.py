#!/usr/bin/env python3
# Live X search follows the xAI docs read on 2026-11-21:
# https://docs.x.ai/developers/tools/x-search
# https://docs.x.ai/developers/model-capabilities/text/structured-outputs
# Client: OpenAI-compatible Responses API, base URL https://api.x.ai/v1,
# model grok-4.7. Tool type x_search with allowed_x_handles (no @) and
# from_date/to_date as YYYY-MM-DD. to_date is exclusive: posts from 00:00 UTC
# on from_date up to, but not including, to_date. Full datetimes are not
# applied, so the last-2-hours window is stated in the prompt and enforced
# again on each timestamp. search_parameters is not used.
# Structured output uses text.format json_schema on responses.create.
# max_turns is sent via extra_body, as documented on the X Search page.

"""Fetch recent physical-security posts from vetted X accounts into hotspots.json."""

from __future__ import annotations

import json
import math
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlparse

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent
HOTSPOTS = ROOT / "hotspots.json"
ARCHIVE = ROOT / "archive.json"
SOURCES = ROOT / "sources.json"

MODEL = "grok-4.7"
BASE_URL = "https://api.x.ai/v1"
HANDLE_LIMIT = 20
ACTIVE_DAYS = 7
LEAD_MATCH_KM = 100
LEAD_MATCH_HOURS = 6

REGIONS = (
    "Gulf",
    "Saudi & Yemen",
    "Levant",
    "Iran & Iraq",
    "Maritime",
    "Other / International",
)
CATEGORIES = (
    "Security Incident",
    "Maritime Advisory",
    "Travel / Embassy Advisory",
)
SEVERITIES = ("high", "medium", "low")
TIERS = (
    "Official / Primary",
    "State-Affiliated / Single-Source",
    "Unverified Lead",
)
OFFICIAL_BATCHES = {
    "travel_advisories_and_embassies",
    "diplomatic_and_international",
}
AGGREGATOR_BATCH = "aggregators_leads_only"

# Government, military, UKMTO, CENTCOM, and official state agencies.
OFFICIAL_HANDLES = {
    "moi_bahrain",
    "bdf_bahrain",
    "kuwaitarmyghq",
    "moinformation",
    "mofaqatar_en",
    "uk_mto",
    "centcom",
    "centcomfarsi",
    "cjfcspox",
    "saudidcd",
    "ksagaca",
    "spa_eng",
    "sparegions",
    "yemen_pm",
    "idf",
    "idfspokesperson",
    "avichayadraee",
    "nnaleb",
    "lebarmyofficial",
    "sanaenofficial",
    "syrianmofaex",
    "irimfa_spox",
    "araghchi",
    "iraqipmo",
}
WIRES = {"reuters", "arareuters", "reutersiran", "ap", "afp", "afpar"}
REGIONAL_OUTLETS = {"bbcarabic", "ajenglish", "alhadath", "alarabytv"}
# Named state media and Ansarallah accounts. IRIB is the state broadcaster
# that operates Press TV, so it uses the same single-source tier.
STATE_AFFILIATED = {
    "presstv",
    "tasnimarabic1",
    "yah_saree",
    "mmy1444",
    "iribnews_irib",
}
OUTLET_LABELS = {
    "presstv": "Press TV",
    "tasnimarabic1": "Tasnim",
    "yah_saree": "Ansarallah spokesman Yahya Saree",
    "mmy1444": "Ansarallah media",
    "iribnews_irib": "IRIB",
    "bbcarabic": "BBC Arabic",
    "ajenglish": "Al Jazeera English",
    "alhadath": "Al Hadath",
    "alarabytv": "Al Araby TV",
}

REGION_ALIASES = {
    "gulf": "Gulf",
    "saudi & yemen": "Saudi & Yemen",
    "saudi and yemen": "Saudi & Yemen",
    "levant": "Levant",
    "iran & iraq": "Iran & Iraq",
    "iran and iraq": "Iran & Iraq",
    "maritime": "Maritime",
    "other / international": "Other / International",
    "other": "Other / International",
}
CATEGORY_ALIASES = {
    "security incident": "Security Incident",
    "maritime advisory": "Maritime Advisory",
    "travel / embassy advisory": "Travel / Embassy Advisory",
    "travel advisory": "Travel / Embassy Advisory",
    "embassy advisory": "Travel / Embassy Advisory",
}

STATUS_URL = re.compile(
    r"^https?://(?:www\.)?(?:x|twitter)\.com/([A-Za-z0-9_]{1,15})/status/(\d+)(?:[/?#].*)?$",
    re.IGNORECASE,
)
NOTE_URL = re.compile(r"https?://[^\s)]+", re.IGNORECASE)

INCIDENT_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "incidents": {
            "type": "array",
            "items": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "longitude": {"type": "number"},
                    "latitude": {"type": "number"},
                    "severity": {"type": "string", "enum": list(SEVERITIES)},
                    "summary": {"type": "string"},
                    "timestamp": {"type": "string"},
                    "source": {"type": "string"},
                    "account": {"type": "string"},
                    "region": {"type": "string", "enum": list(REGIONS)},
                    "category": {"type": "string", "enum": list(CATEGORIES)},
                    "cites_primary_official": {"type": "boolean"},
                    "cites_named_official_or_wire": {"type": "boolean"},
                    "cited_handle": {"type": "string"},
                    "claimant": {"type": "string"},
                },
                "required": [
                    "longitude",
                    "latitude",
                    "severity",
                    "summary",
                    "timestamp",
                    "source",
                    "account",
                    "region",
                    "category",
                    "cites_primary_official",
                    "cites_named_official_or_wire",
                    "cited_handle",
                    "claimant",
                ],
            },
        }
    },
    "required": ["incidents"],
}


def read_api_key() -> str:
    load_dotenv(ROOT / ".env")
    return (os.environ.get("XAI_API_KEY") or "").strip()


def exit_if_no_key() -> str:
    key = read_api_key()
    if not key:
        print(
            "XAI_API_KEY is missing. Add it to the environment or a .env file. "
            "hotspots.json was not changed."
        )
        sys.exit(0)
    return key


def public_error(exc: BaseException, secret: str) -> str:
    message = f"{exc.__class__.__name__}: {exc}"
    if secret:
        message = message.replace(secret, "[redacted]")
    message = re.sub(r"(?i)bearer\s+\S+", "Bearer [redacted]", message)
    message = re.sub(r"(?:sk|xai)-[A-Za-z0-9_\-]+", "[redacted]", message)
    return message[:600]


def load_sources() -> dict:
    try:
        data = json.loads(SOURCES.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"Could not read sources.json ({exc.__class__.__name__}). hotspots.json was not changed.")
        sys.exit(1)
    batches = data.get("batches")
    if not isinstance(batches, dict) or not batches:
        print("sources.json has no batches. hotspots.json was not changed.")
        sys.exit(1)
    excluded = data.get("excluded_handles") or []
    if not isinstance(excluded, list):
        print("sources.json excluded_handles is invalid. hotspots.json was not changed.")
        sys.exit(1)
    return data


def clean_handle(value: object) -> str:
    return str(value or "").strip().lstrip("@")


def excluded_set(handles: list) -> set[str]:
    return {clean_handle(handle).lower() for handle in handles if clean_handle(handle)}


def canonical_handle(value: object, allowed: list[str]) -> str | None:
    key = clean_handle(value).lower()
    if not key:
        return None
    for handle in allowed:
        if handle.lower() == key:
            return handle
    return None


def parse_timestamp(value: object) -> datetime | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    if not text:
        return None
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def format_timestamp(moment: datetime) -> str:
    return moment.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def valid_coord(lon: object, lat: object) -> tuple[float, float] | None:
    try:
        longitude = float(lon)
        latitude = float(lat)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(longitude) or not math.isfinite(latitude):
        return None
    if not (-180 <= longitude <= 180 and -90 <= latitude <= 90):
        return None
    if abs(longitude) < 1e-9 and abs(latitude) < 1e-9:
        return None
    return longitude, latitude


def one_sentence(value: object) -> str:
    return " ".join(str(value or "").split())


def normalize_region(value: object) -> str | None:
    text = " ".join(str(value or "").split())
    if text in REGIONS:
        return text
    return REGION_ALIASES.get(text.lower())


def normalize_category(value: object, batch: str) -> str:
    text = " ".join(str(value or "").split())
    if text in CATEGORIES:
        return text
    alias = CATEGORY_ALIASES.get(text.lower())
    if alias:
        return alias
    if batch == "travel_advisories_and_embassies":
        return "Travel / Embassy Advisory"
    return "Security Incident"


def handle_batches(batches: dict) -> dict[str, str]:
    found: dict[str, str] = {}
    for name, handles in batches.items():
        if not isinstance(handles, list):
            continue
        for handle in handles:
            cleaned = clean_handle(handle)
            if cleaned:
                found[cleaned.lower()] = str(name)
    return found


def is_primary_handle(handle: str, batches_by_handle: dict[str, str]) -> bool:
    key = handle.lower()
    if key in WIRES or key in OFFICIAL_HANDLES:
        return True
    return batches_by_handle.get(key) in OFFICIAL_BATCHES


def assign_tier(handle: str, batch: str, cites_official: bool) -> str:
    key = handle.lower()
    if batch == AGGREGATOR_BATCH:
        return "Unverified Lead"
    if key in REGIONAL_OUTLETS:
        if cites_official:
            return "Official / Primary"
        return "State-Affiliated / Single-Source"
    if key in STATE_AFFILIATED:
        return "State-Affiliated / Single-Source"
    if key in WIRES or key in OFFICIAL_HANDLES or batch in OFFICIAL_BATCHES:
        return "Official / Primary"
    return "State-Affiliated / Single-Source"


def ensure_named(summary: str, handle: str, claimant: str) -> str:
    label = one_sentence(claimant) or OUTLET_LABELS.get(handle.lower()) or handle
    haystack = summary.lower()
    if label.lower() in haystack or handle.lower() in haystack:
        return summary
    return f"{label} said: {summary}"


def blocked_hosts(notes: object) -> set[str]:
    hosts = {"mofa.go.jp", "www.mofa.go.jp"}
    if not isinstance(notes, list):
        return hosts
    for note in notes:
        for match in NOTE_URL.findall(str(note)):
            host = (urlparse(match).hostname or "").lower()
            if host:
                hosts.add(host)
    return hosts


def url_host_blocked(url: str, hosts: set[str]) -> bool:
    host = (urlparse(url).hostname or "").lower()
    if not host:
        return True
    return any(host == blocked or host.endswith("." + blocked) for blocked in hosts)


def status_parts(url: object) -> tuple[str, str] | None:
    if not isinstance(url, str):
        return None
    match = STATUS_URL.match(url.strip())
    if not match:
        return None
    return match.group(1), match.group(2)


def extract_warning_number(text: str) -> str | None:
    match = re.search(
        r"(?i)\b(UKMTO(?:\s*(?:warning|advisory))?\s*#?\s*[A-Z]{0,6}\d[\w\-]*)",
        text or "",
    )
    if not match:
        return None
    return " ".join(match.group(1).split())


def build_feature(
    *,
    lon: float,
    lat: float,
    severity: str,
    summary: str,
    timestamp: str,
    source: str,
    handle: str,
    batch: str,
    tier: str,
    region: str,
    category: str,
    cites_primary: bool,
    title: str = "",
    warning_number: str | None = None,
) -> dict:
    warning = one_sentence(warning_number) or extract_warning_number(summary)
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {
            "severity": severity,
            "title": one_sentence(title) or summary,
            "summary": summary,
            "timestamp": timestamp,
            "source": source,
            "account": handle,
            "handle": handle,
            "source_handle": handle,
            "batch": batch,
            "verification_tier": tier,
            "region": region,
            "category": category,
            "warning_number": warning or None,
            "_cites_primary": cites_primary,
        },
    }


def prepare_incidents(
    raw_items: list,
    *,
    batch: str,
    allowed: list[str],
    excluded: set[str],
    window_start: datetime,
    window_end: datetime,
    batches_by_handle: dict[str, str],
    require_recent: bool,
) -> list[dict]:
    features = []
    seen: set[str] = set()
    for item in raw_items:
        if not isinstance(item, dict):
            continue
        parsed_url = status_parts(item.get("source"))
        if not parsed_url:
            continue
        handle = canonical_handle(parsed_url[0], allowed)
        if not handle or handle.lower() in excluded:
            continue
        account = canonical_handle(item.get("account"), allowed)
        if account and account.lower() != handle.lower():
            continue
        source = f"https://x.com/{handle}/status/{parsed_url[1]}"
        if source in seen:
            continue
        coords = valid_coord(item.get("longitude"), item.get("latitude"))
        if coords is None:
            continue
        severity = str(item.get("severity") or "").strip().lower()
        if severity not in SEVERITIES:
            continue
        summary = one_sentence(item.get("summary"))
        if not summary:
            continue
        moment = parse_timestamp(item.get("timestamp"))
        if moment is None:
            continue
        if require_recent and (moment < window_start or moment > window_end + timedelta(minutes=15)):
            continue
        region = normalize_region(item.get("region"))
        if region is None:
            continue
        category = normalize_category(item.get("category"), batch)
        cited = clean_handle(item.get("cited_handle"))
        if cited.lower() in excluded:
            continue
        cites_named = bool(item.get("cites_named_official_or_wire"))
        cites_primary = bool(item.get("cites_primary_official"))
        if cited and cited.lower() != handle.lower() and is_primary_handle(cited, batches_by_handle):
            cites_named = True
            cites_primary = True
        tier = assign_tier(handle, batch, cites_named or cites_primary)
        if tier == "State-Affiliated / Single-Source":
            summary = ensure_named(summary, handle, str(item.get("claimant") or ""))
        seen.add(source)
        features.append(
            build_feature(
                lon=coords[0],
                lat=coords[1],
                severity=severity,
                summary=summary,
                timestamp=format_timestamp(moment),
                source=source,
                handle=handle,
                batch=batch,
                tier=tier,
                region=region,
                category=category,
                cites_primary=cites_primary or cites_named,
                title=one_sentence(item.get("title") or ""),
                warning_number=item.get("warning_number") if isinstance(item.get("warning_number"), str) else None,
            )
        )
    return features


def haversine_km(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    radius = 6371.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lon = math.radians(lon2 - lon1)
    a = math.sin(d_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lon / 2) ** 2
    return 2 * radius * math.asin(math.sqrt(a))


def feature_time(feature: dict) -> datetime | None:
    return parse_timestamp((feature.get("properties") or {}).get("timestamp"))


def same_incident(left: dict, right: dict) -> bool:
    left_time = feature_time(left)
    right_time = feature_time(right)
    if left_time is None or right_time is None:
        return False
    if abs((left_time - right_time).total_seconds()) > LEAD_MATCH_HOURS * 3600:
        return False
    lon1, lat1 = left["geometry"]["coordinates"][:2]
    lon2, lat2 = right["geometry"]["coordinates"][:2]
    return haversine_km(float(lon1), float(lat1), float(lon2), float(lat2)) <= LEAD_MATCH_KM


def apply_lead_rule(features: list[dict]) -> list[dict]:
    others = []
    leads = []
    for feature in features:
        props = feature.setdefault("properties", {})
        if props.get("batch") == AGGREGATOR_BATCH:
            leads.append(feature)
        else:
            props.pop("_cites_primary", None)
            others.append(feature)
    kept = list(others)
    for lead in leads:
        cites = bool(lead["properties"].pop("_cites_primary", False))
        if cites or any(same_incident(lead, other) for other in others):
            kept.append(lead)
    return kept


def source_of(feature: dict) -> str:
    return str((feature.get("properties") or {}).get("source") or "").strip()


def feature_handle(feature: dict) -> str:
    props = feature.get("properties") or {}
    return clean_handle(props.get("handle") or props.get("account")).lower()


def feature_excluded(feature: dict, excluded: set[str]) -> bool:
    if feature_handle(feature) in excluded:
        return True
    parsed = status_parts(source_of(feature))
    return bool(parsed and parsed[0].lower() in excluded)


def read_collection(path: Path) -> list:
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not read {path.name} ({exc.__class__.__name__})") from exc
    if not isinstance(data, dict) or data.get("type") != "FeatureCollection":
        raise RuntimeError(f"{path.name} is not a GeoJSON FeatureCollection")
    features = data.get("features")
    if not isinstance(features, list):
        raise RuntimeError(f"{path.name} has no features array")
    return features


def write_collection(path: Path, features: list) -> None:
    payload = {"type": "FeatureCollection", "features": features}
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def merge_active_and_archive(
    new_features: list[dict],
    *,
    now: datetime | None = None,
    hotspots_path: Path = HOTSPOTS,
    archive_path: Path = ARCHIVE,
    excluded: set[str] | None = None,
) -> dict[str, int]:
    """Keep incidents from the last 7 days and append older ones to archive.json.

    Archive entries are never deleted. Duplicate source links are kept once.
    """
    moment = now or datetime.now(timezone.utc)
    cutoff = moment - timedelta(days=ACTIVE_DAYS)
    blocked = excluded or set()
    existing = read_collection(hotspots_path)
    combined: list[dict] = []
    seen: set[str] = set()
    for feature in list(new_features) + existing:
        if not isinstance(feature, dict):
            continue
        if feature_excluded(feature, blocked):
            continue
        key = source_of(feature)
        if not key or key in seen:
            continue
        props = feature.setdefault("properties", {})
        props.pop("_cites_primary", None)
        timestamp = parse_timestamp(props.get("timestamp"))
        if timestamp is None:
            continue
        props["timestamp"] = format_timestamp(timestamp)
        seen.add(key)
        combined.append(feature)

    active: list[dict] = []
    retiring: list[dict] = []
    for feature in combined:
        timestamp = feature_time(feature)
        if timestamp is None or timestamp < cutoff:
            retiring.append(feature)
        else:
            active.append(feature)

    archive = read_collection(archive_path) if archive_path.exists() else []
    archived_keys = {source_of(feature) for feature in archive}
    added = 0
    for feature in retiring:
        key = source_of(feature)
        if key and key not in archived_keys:
            archive.append(feature)
            archived_keys.add(key)
            added += 1
    write_collection(hotspots_path, active)
    if archive_path.exists() or added:
        write_collection(archive_path, archive)
    return {"active": len(active), "archived": added}


def response_text(response: object) -> str:
    direct = getattr(response, "output_text", None)
    if isinstance(direct, str) and direct.strip():
        return direct.strip()
    parts: list[str] = []
    for item in getattr(response, "output", None) or []:
        if getattr(item, "type", None) != "message":
            continue
        for content in getattr(item, "content", None) or []:
            if getattr(content, "type", None) == "output_text":
                text = getattr(content, "text", "")
                if text:
                    parts.append(text)
    return "\n".join(parts).strip()


def parse_json_object(text: str) -> dict:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        payload = json.loads(cleaned)
    except json.JSONDecodeError:
        start = cleaned.find("{")
        end = cleaned.rfind("}")
        if start < 0 or end <= start:
            raise
        payload = json.loads(cleaned[start : end + 1])
    if not isinstance(payload, dict):
        raise ValueError("response JSON was not an object")
    return payload


def make_client(api_key: str):
    try:
        from openai import OpenAI
    except ImportError:
        print("The openai package is not installed. Run: pip install -r requirements.txt")
        sys.exit(1)
    return OpenAI(api_key=api_key, base_url=BASE_URL)


def call_model(client, tool: dict, prompt: str, schema_name: str, schema: dict, api_key: str):
    try:
        response = client.responses.create(
            model=MODEL,
            input=prompt,
            tools=[tool],
            text={
                "format": {
                    "type": "json_schema",
                    "name": schema_name,
                    "schema": schema,
                    "strict": True,
                }
            },
            extra_body={"max_turns": 4},
            timeout=120,
        )
    except Exception as exc:
        print(f"xAI request failed: {public_error(exc, api_key)}", file=sys.stderr)
        return None
    text = response_text(response)
    if not text:
        print("xAI response did not include output text.", file=sys.stderr)
        return None
    try:
        payload = parse_json_object(text)
    except (json.JSONDecodeError, ValueError):
        print("xAI response was not valid JSON.", file=sys.stderr)
        return None
    incidents = payload.get("incidents")
    if not isinstance(incidents, list):
        print("xAI response JSON did not contain an incidents array.", file=sys.stderr)
        return None
    return incidents


def chunked(items: list[str], size: int):
    for index in range(0, len(items), size):
        yield items[index : index + size]


def x_prompt(batch: str, handles: list[str], excluded: list[str], start: datetime, end: datetime) -> str:
    handle_line = ", ".join(f"@{handle}" for handle in handles)
    excluded_line = ", ".join(f"@{handle}" for handle in excluded) or "(none)"
    return (
        "Extract physical security incidents (strikes, explosions, clashes, shootings, "
        "and similar), plus maritime or travel advisories when this batch's accounts post them.\n"
        f"Batch: {batch}\n"
        f"Search only these X accounts: {handle_line}\n"
        f"Never include, cite, quote, or mention these accounts: {excluded_line}\n"
        f"UTC window: {format_timestamp(start)} through {format_timestamp(end)}. "
        "Omit anything outside that window.\n"
        "Translate Arabic, Persian, and French into one concise factual English sentence.\n"
        "Do not invent coordinates. Omit an incident if the post does not locate it.\n"
        "severity is exactly high, medium, or low.\n"
        "timestamp is UTC ISO 8601 with a Z suffix, for example 2026-11-21T15:00:00Z.\n"
        "source is the post URL https://x.com/<handle>/status/<id>.\n"
        "account is the handle without @.\n"
        "region is exactly one of: Gulf (Bahrain, Kuwait, Qatar, UAE, Oman); "
        "Saudi & Yemen (Saudi Arabia, Yemen, Red Sea coast); "
        "Levant (Israel, Palestine, Lebanon, Jordan, Syria); "
        "Iran & Iraq (Iran, Iraq, Kurdistan Region); "
        "Maritime (Strait of Hormuz, Bab el-Mandeb, Gulf of Oman, Arabian Sea, UKMTO/JMIC); "
        "Other / International (Turkey, US/UN diplomatic statements, broader advisories).\n"
        "category is exactly one of: Security Incident; Maritime Advisory; Travel / Embassy Advisory.\n"
        "Travel and embassy accounts should use Travel / Embassy Advisory. "
        "UKMTO and other maritime warnings should use Maritime Advisory. "
        "Kinetic events should use Security Incident.\n"
        "Government, military, UKMTO, CENTCOM, Reuters, AP, and AFP (including araReuters, "
        "ReutersIran, and AFPar) are primary official sources. Accounts in "
        "travel_advisories_and_embassies and diplomatic_and_international are also primary official sources.\n"
        "BBCArabic, AJEnglish, AlHadath, and AlarabyTV are official only when the post cites "
        "a named official or a Reuters, AP, or AFP report. Otherwise name the outlet in the summary.\n"
        "PressTV, tasnimarabic1, Yah_Saree, and MMY1444 are state-affiliated single sources. "
        "The summary must name the claimant.\n"
        "aggregators_leads_only accounts are unverified leads. Still return a real in-window "
        "incident from them. Set cites_primary_official true only when that post itself cites "
        "a primary official source. The caller drops uncorroborated leads.\n"
        "Set cites_named_official_or_wire true only when the post names an official body or a wire. "
        "cited_handle is that source without @, or an empty string. "
        "claimant is the person or outlet making the claim, or an empty string for a direct official statement."
    )


def main() -> None:
    api_key = exit_if_no_key()
    sources = load_sources()
    batches = sources["batches"]
    excluded_list = [clean_handle(handle) for handle in sources.get("excluded_handles") or []]
    excluded = excluded_set(excluded_list)
    batches_by_handle = handle_batches(batches)
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(hours=2)
    # Day bounds only. to_date is exclusive, so tomorrow includes all of today.
    from_date = window_start.date().isoformat()
    to_date = (now.date() + timedelta(days=1)).isoformat()
    client = make_client(api_key)

    collected: list[dict] = []
    attempted = 0
    succeeded = 0
    for batch_name, raw_handles in batches.items():
        if not isinstance(raw_handles, list):
            print(f"Skipping {batch_name}: handles are not a list.", file=sys.stderr)
            continue
        allowed = []
        for handle in raw_handles:
            cleaned = clean_handle(handle)
            if cleaned and cleaned.lower() not in excluded and cleaned not in allowed:
                allowed.append(cleaned)
        if not allowed:
            continue
        for group in chunked(allowed, HANDLE_LIMIT):
            attempted += 1
            print(f"Searching {batch_name} ({len(group)} handles)")
            tool = {
                "type": "x_search",
                "allowed_x_handles": group,
                "from_date": from_date,
                "to_date": to_date,
            }
            incidents = call_model(
                client,
                tool,
                x_prompt(str(batch_name), group, excluded_list, window_start, now),
                "incident_batch",
                INCIDENT_SCHEMA,
                api_key,
            )
            if incidents is None:
                continue
            succeeded += 1
            prepared = prepare_incidents(
                incidents,
                batch=str(batch_name),
                allowed=group,
                excluded=excluded,
                window_start=window_start,
                window_end=now,
                batches_by_handle=batches_by_handle,
                require_recent=True,
            )
            print(f"{batch_name}: kept {len(prepared)} of {len(incidents)}")
            collected.extend(prepared)

    if attempted == 0:
        print("No source batches to search. hotspots.json was not changed.")
        sys.exit(1)
    if succeeded == 0:
        print("All xAI searches failed. hotspots.json was not changed.")
        sys.exit(1)
    if succeeded < attempted:
        print(f"{attempted - succeeded} batch search(es) failed. Merging the searches that succeeded.")

    features = apply_lead_rule(collected)
    try:
        stats = merge_active_and_archive(features, now=now, excluded=excluded)
    except RuntimeError as exc:
        print(f"{exc}. hotspots.json was not changed.")
        sys.exit(1)
    print(
        f"Wrote {stats['active']} incidents to {HOTSPOTS.name} "
        f"({stats['archived']} moved to {ARCHIVE.name})."
    )


if __name__ == "__main__":
    main()
